// 文件列表项定义
// Leo @ 2010/10/05

package com.tatait.tataweibo.util.file;

public class FileListItem {
	public String name;			// 完整路径名
	public int type;			// 是文件夹还是文件，0是文本文件，1是文件夹
}